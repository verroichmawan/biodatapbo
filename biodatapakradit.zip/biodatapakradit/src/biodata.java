/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class biodata {
    public void infoNama(){
        System.out.println("Nama : verro bhernadi icchmawan");
    }
    
    public void infoKelas(){
        System.out.println("Kelas : XI-RPL-1");
    }
    
    public void infoAbsen(){
        System.out.println("No.Absen : 31");
    }
    
    public void infoAlamat(){
        System.out.println("Alamat : jl.barongan");
    }
    
    public void infoTTL(){
        System.out.println("TTL : Malang,27-juni-2003");
    }
    
    public void infoHobi(){
        System.out.println("Hobi : Bermain");
    }
}
